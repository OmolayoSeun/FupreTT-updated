package com.omolayoseun.fuprett;

public enum Reply {
    SHOW_DIALOG(0),
    DISMISS_DIALOG(1);
    private final int i;

    Reply(int i) {
        this.i = i;
    }
}
